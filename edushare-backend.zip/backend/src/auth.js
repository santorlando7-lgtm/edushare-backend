const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
    throw new Error('Defina a variável de ambiente JWT_SECRET antes de iniciar o servidor (veja .env.example).');
}

function gerarToken(usuario) {
    return jwt.sign({ id: usuario.id, nome: usuario.nome, email: usuario.email }, JWT_SECRET, {
        expiresIn: '30d'
    });
}

function verificarToken(token) {
    return jwt.verify(token, JWT_SECRET);
}

// Middleware do Express: exige um token válido no cabeçalho Authorization.
function exigirAutenticacao(req, res, next) {
    const cabecalho = req.headers.authorization || '';
    const [, token] = cabecalho.split(' ');

    if (!token) {
        return res.status(401).json({ erro: 'Não autenticado.' });
    }

    try {
        req.usuario = verificarToken(token);
        next();
    } catch (e) {
        return res.status(401).json({ erro: 'Sessão inválida ou expirada.' });
    }
}

module.exports = { gerarToken, verificarToken, exigirAutenticacao };
