const { verificarToken } = require('./auth');
const { infoConversaPara } = require('./conversas');

function configurarSocket(io) {
    // Autentica a conexão usando o mesmo token (JWT) do login via HTTP.
    io.use((socket, next) => {
        try {
            const token = socket.handshake.auth?.token;
            socket.usuario = verificarToken(token);
            next();
        } catch (e) {
            next(new Error('Não autenticado.'));
        }
    });

    io.on('connection', (socket) => {
        // Sala pessoal: usada para avisos de "nova solicitação" e "conexão aceita".
        socket.join(`usuario:${socket.usuario.id}`);

        // O cliente pede para entrar nas salas das conversas que já conhece
        // (uma por DM aceita e uma por grupo). Validamos a permissão aqui
        // para que ninguém escute mensagens de conversas de outras pessoas.
        socket.on('conversas:entrar', (ids) => {
            if (!Array.isArray(ids)) return;
            ids.forEach((conversationId) => {
                if (typeof conversationId !== 'string') return;
                if (infoConversaPara(socket.usuario.id, conversationId)) {
                    socket.join(`conversa:${conversationId}`);
                }
            });
        });

        socket.on('conversa:entrar', (conversationId) => {
            if (typeof conversationId === 'string' && infoConversaPara(socket.usuario.id, conversationId)) {
                socket.join(`conversa:${conversationId}`);
            }
        });
    });
}

module.exports = configurarSocket;
