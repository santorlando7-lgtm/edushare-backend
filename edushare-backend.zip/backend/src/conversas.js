const db = require('./db');

// Id de conversa individual (DM): sempre os dois ids de usuário em ordem
// crescente, então "dm:3:7" é igual para os dois participantes.
function idConversaDm(userIdA, userIdB) {
    const [menor, maior] = [userIdA, userIdB].sort((a, b) => a - b);
    return `dm:${menor}:${maior}`;
}

function idConversaGrupo(groupId) {
    return `grp:${groupId}`;
}

// Verifica se o usuário pode ler/escrever nessa conversa e retorna
// informações úteis sobre ela (tipo, outro participante ou grupo).
function infoConversaPara(userId, conversationId) {
    if (conversationId.startsWith('dm:')) {
        const [, a, b] = conversationId.split(':').map(Number);
        if (userId !== a && userId !== b) return null;

        const outroId = userId === a ? b : a;
        const conexao = db.prepare(`
            SELECT * FROM connections
            WHERE status = 'aceita'
              AND ((solicitante_id = ? AND destinatario_id = ?) OR (solicitante_id = ? AND destinatario_id = ?))
        `).get(a, b, b, a);

        if (!conexao) return null;

        const outroUsuario = db.prepare('SELECT id, nome FROM users WHERE id = ?').get(outroId);
        if (!outroUsuario) return null;

        return { tipo: 'dm', outroUsuario };
    }

    if (conversationId.startsWith('grp:')) {
        const groupId = Number(conversationId.slice(4));
        const membro = db.prepare('SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, userId);
        if (!membro) return null;

        const grupo = db.prepare('SELECT * FROM groups WHERE id = ?').get(groupId);
        if (!grupo) return null;

        return { tipo: 'grupo', grupo };
    }

    return null;
}

module.exports = { idConversaDm, idConversaGrupo, infoConversaPara };
