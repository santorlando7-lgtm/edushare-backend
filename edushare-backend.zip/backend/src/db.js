const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DATABASE_PATH = process.env.DATABASE_PATH || './data/edushare.db';

// Garante que a pasta do banco de dados existe antes de abrir o arquivo.
const pastaDoBanco = path.dirname(DATABASE_PATH);
if (!fs.existsSync(pastaDoBanco)) {
    fs.mkdirSync(pastaDoBanco, { recursive: true });
}

const db = new Database(DATABASE_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        senha_hash TEXT NOT NULL,
        criado_em TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS profiles (
        user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
        ensina TEXT,
        aprende TEXT NOT NULL,
        atualizado_em TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS connections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        solicitante_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        destinatario_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        status TEXT NOT NULL DEFAULT 'pendente', -- 'pendente' | 'aceita'
        criado_em TEXT NOT NULL DEFAULT (datetime('now')),
        UNIQUE (solicitante_id, destinatario_id)
    );

    CREATE TABLE IF NOT EXISTS groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        criador_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        criado_em TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS group_members (
        group_id INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        PRIMARY KEY (group_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        conversation_id TEXT NOT NULL,
        autor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        autor_nome TEXT NOT NULL,
        tipo TEXT NOT NULL DEFAULT 'texto', -- 'texto' | 'sistema'
        texto TEXT NOT NULL,
        criado_em TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages (conversation_id, criado_em);

    CREATE TABLE IF NOT EXISTS conversation_reads (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        conversation_id TEXT NOT NULL,
        last_read_at TEXT NOT NULL DEFAULT (datetime('now')),
        PRIMARY KEY (user_id, conversation_id)
    );

    CREATE TABLE IF NOT EXISTS video_rooms (
        conversation_id TEXT PRIMARY KEY,
        token TEXT NOT NULL
    );
`);

module.exports = db;
