const express = require('express');
const db = require('../db');
const { exigirAutenticacao } = require('../auth');
const { idConversaDm } = require('../conversas');

const router = express.Router();
router.use(exigirAutenticacao);

// Lista as conexões já aceitas do usuário autenticado (usado para montar grupos).
router.get('/aceitas', (req, res) => {
    const meuId = req.usuario.id;
    const linhas = db.prepare(`
        SELECT u.id, u.nome
        FROM connections c
        JOIN users u ON u.id = (CASE WHEN c.solicitante_id = ? THEN c.destinatario_id ELSE c.solicitante_id END)
        WHERE c.status = 'aceita' AND (c.solicitante_id = ? OR c.destinatario_id = ?)
    `).all(meuId, meuId, meuId);

    res.json({ conexoes: linhas });
});

router.post('/', (req, res) => {
    const meuId = req.usuario.id;
    const destinatarioId = Number(req.body.destinatario_id);

    if (!destinatarioId || destinatarioId === meuId) {
        return res.status(400).json({ erro: 'Destinatário inválido.' });
    }

    const destinatario = db.prepare('SELECT id, nome FROM users WHERE id = ?').get(destinatarioId);
    if (!destinatario) {
        return res.status(404).json({ erro: 'Usuário não encontrado.' });
    }

    const existente = db.prepare(`
        SELECT * FROM connections
        WHERE (solicitante_id = ? AND destinatario_id = ?) OR (solicitante_id = ? AND destinatario_id = ?)
    `).get(meuId, destinatarioId, destinatarioId, meuId);

    if (existente) {
        return res.status(409).json({ erro: 'Já existe uma conexão ou solicitação com esse usuário.' });
    }

    const resultado = db.prepare(`
        INSERT INTO connections (solicitante_id, destinatario_id, status) VALUES (?, ?, 'pendente')
    `).run(meuId, destinatarioId);

    const io = req.app.get('io');
    io.to(`usuario:${destinatarioId}`).emit('conexao:recebida', {
        conexaoId: resultado.lastInsertRowid,
        de: { id: meuId, nome: req.usuario.nome }
    });

    res.status(201).json({ ok: true, conexaoId: resultado.lastInsertRowid });
});

router.post('/:id/aceitar', (req, res) => {
    const meuId = req.usuario.id;
    const conexaoId = Number(req.params.id);

    const conexao = db.prepare('SELECT * FROM connections WHERE id = ?').get(conexaoId);
    if (!conexao || conexao.destinatario_id !== meuId) {
        return res.status(404).json({ erro: 'Solicitação não encontrada.' });
    }
    if (conexao.status === 'aceita') {
        return res.status(409).json({ erro: 'Essa conexão já foi aceita.' });
    }

    db.prepare("UPDATE connections SET status = 'aceita' WHERE id = ?").run(conexaoId);

    const conversationId = idConversaDm(conexao.solicitante_id, conexao.destinatario_id);
    db.prepare(`
        INSERT INTO messages (conversation_id, autor_id, autor_nome, tipo, texto)
        VALUES (?, NULL, 'Sistema', 'sistema', ?)
    `).run(conversationId, 'Conexão aceita. Agora vocês já podem trocar conhecimento por aqui.');

    const io = req.app.get('io');
    io.to(`usuario:${conexao.solicitante_id}`).emit('conexao:aceita', {
        conversationId,
        por: { id: meuId, nome: req.usuario.nome }
    });

    res.json({ ok: true, conversationId });
});

module.exports = router;
