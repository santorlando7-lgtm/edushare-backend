const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { gerarToken, exigirAutenticacao } = require('../auth');

const router = express.Router();

router.post('/registro', async (req, res) => {
    const nome = String(req.body.nome || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const senha = String(req.body.senha || '');

    if (!nome || !email || senha.length < 6) {
        return res.status(400).json({ erro: 'Preencha nome, e-mail e uma senha com 6 ou mais caracteres.' });
    }

    const jaExiste = db.prepare('SELECT 1 FROM users WHERE email = ?').get(email);
    if (jaExiste) {
        return res.status(409).json({ erro: 'Já existe uma conta com esse e-mail.' });
    }

    const senhaHash = await bcrypt.hash(senha, 10);
    const resultado = db.prepare('INSERT INTO users (nome, email, senha_hash) VALUES (?, ?, ?)').run(nome, email, senhaHash);
    const usuario = { id: resultado.lastInsertRowid, nome, email };

    res.status(201).json({ token: gerarToken(usuario), usuario });
});

router.post('/login', async (req, res) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const senha = String(req.body.senha || '');

    const linha = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    const senhaConfere = linha ? await bcrypt.compare(senha, linha.senha_hash) : false;

    if (!linha || !senhaConfere) {
        return res.status(401).json({ erro: 'E-mail ou senha incorretos.' });
    }

    const usuario = { id: linha.id, nome: linha.nome, email: linha.email };
    res.json({ token: gerarToken(usuario), usuario });
});

router.get('/me', exigirAutenticacao, (req, res) => {
    const linha = db.prepare('SELECT id, nome, email FROM users WHERE id = ?').get(req.usuario.id);
    if (!linha) return res.status(401).json({ erro: 'Conta não encontrada.' });
    res.json({ usuario: linha });
});

module.exports = router;
