const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { exigirAutenticacao } = require('../auth');
const { idConversaDm, idConversaGrupo, infoConversaPara } = require('../conversas');

const router = express.Router();
router.use(exigirAutenticacao);

function ultimaMensagem(conversationId) {
    return db.prepare(`
        SELECT autor_nome, texto, criado_em FROM messages
        WHERE conversation_id = ? ORDER BY id DESC LIMIT 1
    `).get(conversationId);
}

function contarNaoLidas(userId, conversationId) {
    const leitura = db.prepare(`
        SELECT last_read_at FROM conversation_reads WHERE user_id = ? AND conversation_id = ?
    `).get(userId, conversationId);
    const desde = leitura ? leitura.last_read_at : '1970-01-01';

    const linha = db.prepare(`
        SELECT COUNT(*) AS total FROM messages
        WHERE conversation_id = ? AND criado_em > ? AND (autor_id IS NULL OR autor_id != ?)
    `).get(conversationId, desde, userId);

    return linha.total;
}

// Lista as conversas (DMs aceitas + grupos) do usuário autenticado.
router.get('/', (req, res) => {
    const meuId = req.usuario.id;

    const dms = db.prepare(`
        SELECT u.id AS outro_id, u.nome AS outro_nome
        FROM connections c
        JOIN users u ON u.id = (CASE WHEN c.solicitante_id = ? THEN c.destinatario_id ELSE c.solicitante_id END)
        WHERE c.status = 'aceita' AND (c.solicitante_id = ? OR c.destinatario_id = ?)
    `).all(meuId, meuId, meuId).map((d) => {
        const conversationId = idConversaDm(meuId, d.outro_id);
        return {
            conversationId,
            tipo: 'dm',
            titulo: d.outro_nome,
            ultimaMensagem: ultimaMensagem(conversationId) || null,
            naoLidas: contarNaoLidas(meuId, conversationId)
        };
    });

    const grupos = db.prepare(`
        SELECT g.id, g.nome FROM group_members gm
        JOIN groups g ON g.id = gm.group_id
        WHERE gm.user_id = ?
    `).all(meuId).map((g) => {
        const conversationId = idConversaGrupo(g.id);
        return {
            conversationId,
            tipo: 'grupo',
            titulo: g.nome,
            ultimaMensagem: ultimaMensagem(conversationId) || null,
            naoLidas: contarNaoLidas(meuId, conversationId)
        };
    });

    const pendentesRecebidas = db.prepare(`
        SELECT c.id AS conexao_id, u.nome
        FROM connections c
        JOIN users u ON u.id = c.solicitante_id
        WHERE c.destinatario_id = ? AND c.status = 'pendente'
    `).all(meuId);

    res.json({ conversas: [...grupos, ...dms], pendentesRecebidas });
});

router.get('/:id/mensagens', (req, res) => {
    const info = infoConversaPara(req.usuario.id, req.params.id);
    if (!info) return res.status(403).json({ erro: 'Você não participa dessa conversa.' });

    const mensagens = db.prepare(`
        SELECT id, autor_id, autor_nome, tipo, texto, criado_em FROM messages
        WHERE conversation_id = ? ORDER BY id ASC
    `).all(req.params.id);

    res.json({ mensagens, info });
});

router.post('/:id/mensagens', (req, res) => {
    const conversationId = req.params.id;
    const info = infoConversaPara(req.usuario.id, conversationId);
    if (!info) return res.status(403).json({ erro: 'Você não participa dessa conversa.' });

    const texto = String(req.body.texto || '').trim().slice(0, 2000);
    if (!texto) return res.status(400).json({ erro: 'Mensagem vazia.' });

    const resultado = db.prepare(`
        INSERT INTO messages (conversation_id, autor_id, autor_nome, tipo, texto)
        VALUES (?, ?, ?, 'texto', ?)
    `).run(conversationId, req.usuario.id, req.usuario.nome, texto);

    const mensagem = db.prepare('SELECT id, autor_id, autor_nome, tipo, texto, criado_em FROM messages WHERE id = ?').get(resultado.lastInsertRowid);

    db.prepare(`
        INSERT INTO conversation_reads (user_id, conversation_id, last_read_at)
        VALUES (?, ?, datetime('now'))
        ON CONFLICT(user_id, conversation_id) DO UPDATE SET last_read_at = datetime('now')
    `).run(req.usuario.id, conversationId);

    req.app.get('io').to(`conversa:${conversationId}`).emit('mensagem:nova', { conversationId, mensagem });

    res.status(201).json({ mensagem });
});

router.post('/:id/lida', (req, res) => {
    const info = infoConversaPara(req.usuario.id, req.params.id);
    if (!info) return res.status(403).json({ erro: 'Você não participa dessa conversa.' });

    db.prepare(`
        INSERT INTO conversation_reads (user_id, conversation_id, last_read_at)
        VALUES (?, ?, datetime('now'))
        ON CONFLICT(user_id, conversation_id) DO UPDATE SET last_read_at = datetime('now')
    `).run(req.usuario.id, req.params.id);

    res.json({ ok: true });
});

// Sala de videochamada: usa o serviço público e gratuito Jitsi Meet.
// O token é gerado uma vez por conversa e reaproveitado — assim todo
// participante que entra na mesma conversa cai na mesma sala.
router.get('/:id/sala-video', (req, res) => {
    const conversationId = req.params.id;
    const info = infoConversaPara(req.usuario.id, conversationId);
    if (!info) return res.status(403).json({ erro: 'Você não participa dessa conversa.' });

    let linha = db.prepare('SELECT token FROM video_rooms WHERE conversation_id = ?').get(conversationId);
    if (!linha) {
        const token = crypto.randomBytes(8).toString('hex');
        db.prepare('INSERT INTO video_rooms (conversation_id, token) VALUES (?, ?)').run(conversationId, token);
        linha = { token };
    }

    res.json({ link: `https://meet.jit.si/EduShare-${linha.token}` });
});

module.exports = router;
