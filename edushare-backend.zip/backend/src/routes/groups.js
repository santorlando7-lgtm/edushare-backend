const express = require('express');
const db = require('../db');
const { exigirAutenticacao } = require('../auth');
const { idConversaGrupo } = require('../conversas');

const router = express.Router();
router.use(exigirAutenticacao);

function saoConexoesAceitas(meuId, idsAlvo) {
    if (idsAlvo.length === 0) return true;
    const placeholders = idsAlvo.map(() => '?').join(',');
    const linhas = db.prepare(`
        SELECT (CASE WHEN solicitante_id = ? THEN destinatario_id ELSE solicitante_id END) AS outro_id
        FROM connections
        WHERE status = 'aceita' AND (solicitante_id = ? OR destinatario_id = ?)
          AND (solicitante_id IN (${placeholders}) OR destinatario_id IN (${placeholders}))
    `).all(meuId, meuId, meuId, ...idsAlvo, ...idsAlvo);

    const permitidos = new Set(linhas.map((l) => l.outro_id));
    return idsAlvo.every((id) => permitidos.has(id));
}

router.post('/', (req, res) => {
    const meuId = req.usuario.id;
    const nome = String(req.body.nome || '').trim();
    const membros = Array.isArray(req.body.membros) ? [...new Set(req.body.membros.map(Number))].filter((id) => id !== meuId) : [];

    if (!nome) return res.status(400).json({ erro: 'Dê um nome ao grupo.' });
    if (membros.length === 0) return res.status(400).json({ erro: 'Selecione ao menos um membro.' });
    if (!saoConexoesAceitas(meuId, membros)) {
        return res.status(403).json({ erro: 'Você só pode adicionar conexões já aceitas.' });
    }

    const resultado = db.prepare('INSERT INTO groups (nome, criador_id) VALUES (?, ?)').run(nome, meuId);
    const groupId = resultado.lastInsertRowid;

    const inserirMembro = db.prepare('INSERT INTO group_members (group_id, user_id) VALUES (?, ?)');
    inserirMembro.run(groupId, meuId);
    membros.forEach((id) => inserirMembro.run(groupId, id));

    const conversationId = idConversaGrupo(groupId);
    const nomesMembros = db.prepare(`SELECT nome FROM users WHERE id IN (${membros.map(() => '?').join(',')})`).all(...membros).map((l) => l.nome);

    db.prepare(`
        INSERT INTO messages (conversation_id, autor_id, autor_nome, tipo, texto)
        VALUES (?, NULL, 'Sistema', 'sistema', ?)
    `).run(conversationId, `${req.usuario.nome} criou o grupo com ${nomesMembros.join(', ')}.`);

    const io = req.app.get('io');
    [...membros].forEach((id) => {
        io.to(`usuario:${id}`).emit('grupo:adicionado', { conversationId, nome });
    });

    res.status(201).json({ ok: true, conversationId, grupo: { id: groupId, nome } });
});

router.post('/:id/membros', (req, res) => {
    const meuId = req.usuario.id;
    const groupId = Number(req.params.id);
    const novosMembros = Array.isArray(req.body.membros) ? [...new Set(req.body.membros.map(Number))] : [];

    const souMembro = db.prepare('SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?').get(groupId, meuId);
    if (!souMembro) return res.status(403).json({ erro: 'Você não participa desse grupo.' });
    if (novosMembros.length === 0) return res.status(400).json({ erro: 'Selecione ao menos um membro.' });
    if (!saoConexoesAceitas(meuId, novosMembros)) {
        return res.status(403).json({ erro: 'Você só pode adicionar conexões já aceitas.' });
    }

    const jaMembros = new Set(
        db.prepare('SELECT user_id FROM group_members WHERE group_id = ?').all(groupId).map((l) => l.user_id)
    );
    const paraAdicionar = novosMembros.filter((id) => !jaMembros.has(id));
    if (paraAdicionar.length === 0) {
        return res.status(409).json({ erro: 'Esses usuários já estão no grupo.' });
    }

    const inserirMembro = db.prepare('INSERT INTO group_members (group_id, user_id) VALUES (?, ?)');
    paraAdicionar.forEach((id) => inserirMembro.run(groupId, id));

    const conversationId = idConversaGrupo(groupId);
    const nomesNovos = db.prepare(`SELECT nome FROM users WHERE id IN (${paraAdicionar.map(() => '?').join(',')})`).all(...paraAdicionar).map((l) => l.nome);

    db.prepare(`
        INSERT INTO messages (conversation_id, autor_id, autor_nome, tipo, texto)
        VALUES (?, NULL, 'Sistema', 'sistema', ?)
    `).run(conversationId, `${req.usuario.nome} adicionou ${nomesNovos.join(', ')} ao grupo.`);

    const io = req.app.get('io');
    const grupo = db.prepare('SELECT nome FROM groups WHERE id = ?').get(groupId);
    paraAdicionar.forEach((id) => {
        io.to(`usuario:${id}`).emit('grupo:adicionado', { conversationId, nome: grupo.nome });
    });
    io.to(`conversa:${conversationId}`).emit('mensagem:nova', ultimaMensagem(conversationId));

    res.json({ ok: true });
});

function ultimaMensagem(conversationId) {
    return db.prepare(`
        SELECT * FROM messages WHERE conversation_id = ? ORDER BY id DESC LIMIT 1
    `).get(conversationId);
}

module.exports = router;
