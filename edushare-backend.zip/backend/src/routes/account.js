const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db');
const { exigirAutenticacao } = require('../auth');

const router = express.Router();
router.use(exigirAutenticacao);

router.delete('/', async (req, res) => {
    const meuId = req.usuario.id;
    const senha = String(req.body.senha || '');

    const linha = db.prepare('SELECT senha_hash FROM users WHERE id = ?').get(meuId);
    if (!linha) return res.status(404).json({ erro: 'Conta não encontrada.' });

    const senhaConfere = await bcrypt.compare(senha, linha.senha_hash);
    if (!senhaConfere) return res.status(401).json({ erro: 'Senha incorreta.' });

    // ON DELETE CASCADE cuida de profiles, connections e group_members.
    // Mensagens e salas de vídeo ficam fora do CASCADE de propósito: o
    // histórico de uma conversa não deve sumir inteiro só porque uma
    // das pessoas apagou a conta — o autor_id vira NULL (ver schema).
    db.prepare('DELETE FROM users WHERE id = ?').run(meuId);

    res.json({ ok: true });
});

module.exports = router;
