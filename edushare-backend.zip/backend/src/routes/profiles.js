const express = require('express');
const db = require('../db');
const { exigirAutenticacao } = require('../auth');
const { idConversaDm } = require('../conversas');

const router = express.Router();
router.use(exigirAutenticacao);

// Cria ou atualiza o perfil de troca do usuário autenticado.
router.post('/', (req, res) => {
    const ensina = String(req.body.ensina || '').trim();
    const aprende = String(req.body.aprende || '').trim();

    if (!aprende) {
        return res.status(400).json({ erro: 'Informe ao menos o que você quer aprender.' });
    }
    if (ensina && ensina === aprende) {
        return res.status(400).json({ erro: 'O assunto oferecido não pode ser igual ao objetivo de estudo.' });
    }

    db.prepare(`
        INSERT INTO profiles (user_id, ensina, aprende, atualizado_em)
        VALUES (?, ?, ?, datetime('now'))
        ON CONFLICT(user_id) DO UPDATE SET ensina = excluded.ensina, aprende = excluded.aprende, atualizado_em = datetime('now')
    `).run(req.usuario.id, ensina || null, aprende);

    res.status(201).json({ ok: true });
});

// Lista todos os perfis publicados, com o status de conexão em relação
// ao usuário autenticado (própria, nenhuma, pendente enviada/recebida, aceita).
router.get('/', (req, res) => {
    const meuId = req.usuario.id;

    const perfis = db.prepare(`
        SELECT u.id AS user_id, u.nome, p.ensina, p.aprende
        FROM profiles p
        JOIN users u ON u.id = p.user_id
        ORDER BY p.atualizado_em DESC
    `).all();

    const conexoes = db.prepare(`
        SELECT * FROM connections WHERE solicitante_id = ? OR destinatario_id = ?
    `).all(meuId, meuId);

    const resultado = perfis.map((p) => {
        if (p.user_id === meuId) {
            return { ...p, statusConexao: 'propria', conversationId: null, conexaoId: null };
        }

        const conexao = conexoes.find((c) => c.solicitante_id === p.user_id || c.destinatario_id === p.user_id);
        let statusConexao = 'nenhuma';
        let conversationId = null;

        if (conexao) {
            if (conexao.status === 'aceita') {
                statusConexao = 'aceita';
                conversationId = idConversaDm(meuId, p.user_id);
            } else if (conexao.solicitante_id === meuId) {
                statusConexao = 'pendente_enviada';
            } else {
                statusConexao = 'pendente_recebida';
            }
        }

        return { ...p, statusConexao, conversationId, conexaoId: conexao ? conexao.id : null };
    });

    res.json({ perfis: resultado });
});

module.exports = router;
