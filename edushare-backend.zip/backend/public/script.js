/* =========================================================
   Configuração e utilitários
   ========================================================= */
const API_BASE = window.location.origin;

const AVATAR_PALETTE = [
    { bg: '#eef2ff', fg: '#1d4ed8' },
    { bg: '#f0fdf4', fg: '#15803d' },
    { bg: '#fef3c7', fg: '#b45309' },
    { bg: '#fce7f3', fg: '#be185d' },
    { bg: '#ecfeff', fg: '#0e7490' }
];

function corDoAvatar(nome) {
    const indice = (nome || '').split('').reduce((acc, ch) => acc + ch.charCodeAt(0), 0) % AVATAR_PALETTE.length;
    return AVATAR_PALETTE[indice];
}

function gerarIniciais(nomeCompleto) {
    const partes = (nomeCompleto || '').trim().split(/\s+/);
    const primeira = partes[0]?.[0] || '';
    const ultima = partes.length > 1 ? partes[partes.length - 1][0] : '';
    return (primeira + ultima).toUpperCase();
}

function esc(valor) {
    return String(valor ?? '').replace(/[&<>"']/g, (c) => (
        { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
}

function mostrarToast(titulo, mensagem, tipo) {
    const stack = document.getElementById('toastStack');
    const toast = document.createElement('div');
    toast.className = 'toast' + (tipo ? ' ' + tipo : '');
    const strong = document.createElement('strong');
    strong.textContent = titulo;
    toast.append(strong, document.createTextNode(mensagem));
    stack.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('leaving');
        setTimeout(() => toast.remove(), 200);
    }, 4200);
}

function definirCarregando(botao, carregando, textoNormal) {
    botao.disabled = carregando;
    botao.innerHTML = carregando ? '<span class="spinner"></span> Processando' : textoNormal;
}

// Cliente de API: sempre manda o token salvo e já trata erros no formato { erro: '...' }.
async function api(caminho, { metodo = 'GET', corpo } = {}) {
    const headers = { 'Content-Type': 'application/json' };
    const token = localStorage.getItem('edushare_token');
    if (token) headers.Authorization = `Bearer ${token}`;

    const resposta = await fetch(`${API_BASE}${caminho}`, {
        method: metodo,
        headers,
        body: corpo ? JSON.stringify(corpo) : undefined
    });

    let dados = null;
    try { dados = await resposta.json(); } catch (e) { /* sem corpo JSON */ }

    if (!resposta.ok) {
        const erro = new Error((dados && dados.erro) || 'Algo deu errado. Tente novamente.');
        erro.status = resposta.status;
        throw erro;
    }
    return dados;
}

/* =========================================================
   Autenticação
   ========================================================= */
const authSection = document.getElementById('authSection');
const appSection = document.getElementById('appSection');

const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const loginError = document.getElementById('loginError');
const registerError = document.getElementById('registerError');

const authSwitchBtn = document.getElementById('authSwitchBtn');
const authSwitchText = document.getElementById('authSwitchText');
const authSubtitle = document.getElementById('authSubtitle');

const usuarioLogadoNome = document.getElementById('usuarioLogadoNome');
const usuarioLogadoAvatar = document.getElementById('usuarioLogadoAvatar');
const btnLogout = document.getElementById('btnLogout');

let contaAtual = null; // { id, nome, email }
let socket = null;
let viewAtual = 'explorar';
let chatAtivoId = null;
let conversasCache = [];
let perfisCache = [];
let modalGrupoModo = 'criar';

document.querySelectorAll('.toggle-password').forEach((btn) => {
    btn.addEventListener('click', () => {
        const alvo = document.getElementById(btn.dataset.target);
        const visivel = alvo.type === 'text';
        alvo.type = visivel ? 'password' : 'text';
        btn.textContent = visivel ? 'mostrar' : 'ocultar';
    });
});

function alternarTelaAuth(mostrarCadastro) {
    loginForm.classList.toggle('hidden', mostrarCadastro);
    registerForm.classList.toggle('hidden', !mostrarCadastro);
    loginError.classList.remove('visible');
    registerError.classList.remove('visible');

    if (mostrarCadastro) {
        authSubtitle.textContent = 'Crie sua conta para publicar sua disponibilidade.';
        authSwitchText.textContent = 'Já tem conta?';
        authSwitchBtn.textContent = 'Entrar';
    } else {
        authSubtitle.textContent = 'Entre para acessar a rede de mentoria.';
        authSwitchText.textContent = 'Ainda não tem conta?';
        authSwitchBtn.textContent = 'Cadastre-se';
    }
}

authSwitchBtn.addEventListener('click', () => {
    alternarTelaAuth(!registerForm.classList.contains('hidden') ? false : true);
});

function entrarNaAplicacao(usuario, token) {
    contaAtual = usuario;
    if (token) localStorage.setItem('edushare_token', token);

    authSection.classList.add('hidden');
    appSection.classList.remove('hidden');
    usuarioLogadoNome.textContent = usuario.nome;

    const cor = corDoAvatar(usuario.nome);
    usuarioLogadoAvatar.textContent = gerarIniciais(usuario.nome);
    usuarioLogadoAvatar.style.background = cor.bg;
    usuarioLogadoAvatar.style.color = cor.fg;

    conectarSocket();
    chatAtivoId = null;
    trocarView('explorar');
}

function sair() {
    localStorage.removeItem('edushare_token');
    contaAtual = null;
    chatAtivoId = null;
    conversasCache = [];
    perfisCache = [];
    if (socket) { socket.disconnect(); socket = null; }

    document.querySelectorAll('.modal-overlay').forEach((m) => m.classList.add('hidden'));
    document.getElementById('videoFrame').innerHTML = '';
    document.getElementById('listaChats').innerHTML = '';
    document.getElementById('listaUsuarios').innerHTML = '';

    appSection.classList.add('hidden');
    authSection.classList.remove('hidden');
    alternarTelaAuth(false);
}

btnLogout.addEventListener('click', sair);

registerForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const botao = registerForm.querySelector('.btn-submit');

    const nome = document.getElementById('registerNome').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const senha = document.getElementById('registerSenha').value;

    registerError.classList.remove('visible');
    definirCarregando(botao, true);
    try {
        const { token, usuario } = await api('/api/auth/registro', { metodo: 'POST', corpo: { nome, email, senha } });
        registerForm.reset();
        entrarNaAplicacao(usuario, token);
        mostrarToast('Conta criada', 'Bem-vindo(a) à rede EduShare.', 'success');
    } catch (e) {
        registerError.textContent = e.message;
        registerError.classList.add('visible');
    } finally {
        definirCarregando(botao, false, 'Criar conta');
    }
});

loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const botao = loginForm.querySelector('.btn-submit');

    const email = document.getElementById('loginEmail').value.trim();
    const senha = document.getElementById('loginSenha').value;

    loginError.classList.remove('visible');
    definirCarregando(botao, true);
    try {
        const { token, usuario } = await api('/api/auth/login', { metodo: 'POST', corpo: { email, senha } });
        loginForm.reset();
        entrarNaAplicacao(usuario, token);
    } catch (e) {
        loginError.textContent = e.message;
        loginError.classList.add('visible');
    } finally {
        definirCarregando(botao, false, 'Entrar');
    }
});

// Restaura a sessão se já houver um token salvo.
(async function restaurarSessao() {
    const token = localStorage.getItem('edushare_token');
    if (!token) return;
    try {
        const { usuario } = await api('/api/auth/me');
        entrarNaAplicacao(usuario, null);
    } catch (e) {
        localStorage.removeItem('edushare_token');
    }
})();

/* =========================================================
   Tempo real (Socket.io)
   ========================================================= */
function conectarSocket() {
    const token = localStorage.getItem('edushare_token');
    socket = io(API_BASE, { auth: { token } });

    socket.on('connect', () => {
        const idsConversas = conversasCache.map((c) => c.conversationId);
        if (idsConversas.length) socket.emit('conversas:entrar', idsConversas);
    });

    socket.on('mensagem:nova', ({ conversationId, mensagem }) => {
        const minhaMensagem = mensagem.autor_id === contaAtual.id;
        if (viewAtual === 'privada' && chatAtivoId === conversationId) {
            renderizarMensagemNaTela(mensagem);
            marcarComoLido(conversationId, { silencioso: true });
        } else if (!minhaMensagem) {
            mostrarToast(mensagem.autor_nome, mensagem.texto, 'success');
        }
        carregarConversas();
    });

    socket.on('conexao:recebida', ({ de }) => {
        mostrarToast('Nova solicitação', `${de.nome} quer se conectar com você.`, 'success');
        if (viewAtual === 'explorar') carregarPerfis();
        carregarConversas();
    });

    socket.on('conexao:aceita', ({ por }) => {
        mostrarToast('Conexão aceita', `${por.nome} aceitou sua solicitação.`, 'success');
        if (viewAtual === 'explorar') carregarPerfis();
        carregarConversas();
    });

    socket.on('grupo:adicionado', ({ conversationId, nome }) => {
        mostrarToast('Novo grupo', `Você foi adicionado ao grupo "${nome}".`, 'success');
        carregarConversas().then(() => socket.emit('conversa:entrar', conversationId));
    });
}

/* =========================================================
   Navegação entre Explorar e Área privada
   ========================================================= */
document.querySelectorAll('.nav-tab').forEach((btn) => {
    btn.addEventListener('click', () => trocarView(btn.dataset.view));
});

async function trocarView(nome) {
    viewAtual = nome;
    document.getElementById('viewExplorar').classList.toggle('hidden', nome !== 'explorar');
    document.getElementById('viewPrivada').classList.toggle('hidden', nome !== 'privada');
    document.querySelectorAll('.nav-tab').forEach((b) => b.classList.toggle('active', b.dataset.view === nome));

    if (nome === 'privada') {
        await carregarConversas();
        if (chatAtivoId) marcarComoLido(chatAtivoId);
    } else {
        await carregarPerfis();
    }
}

function atualizarBadge() {
    const badge = document.getElementById('badgeConexoes');
    const total = conversasCache.reduce((soma, c) => soma + (c.naoLidas || 0), 0);
    badge.textContent = total;
    badge.classList.toggle('hidden', total === 0);
}

/* =========================================================
   Rede de mentoria (Explorar)
   ========================================================= */
const listaUsuariosContainer = document.getElementById('listaUsuarios');
const cadastroForm = document.getElementById('cadastroForm');

async function carregarPerfis() {
    try {
        const { perfis } = await api('/api/profiles');
        perfisCache = perfis;
        renderizarUsuarios();
    } catch (e) {
        mostrarToast('Erro ao carregar membros', e.message, 'error');
    }
}

const ROTULOS_BOTAO = {
    propria: { texto: 'Seu perfil', desativado: true, classe: '' },
    nenhuma: { texto: 'Propor conexão', desativado: false, classe: '' },
    pendente_enviada: { texto: 'Solicitação enviada', desativado: true, classe: '' },
    pendente_recebida: { texto: 'Aceitar conexão', desativado: false, classe: 'accent' },
    aceita: { texto: 'Abrir conversa', desativado: false, classe: 'accent' }
};

function renderizarUsuarios() {
    listaUsuariosContainer.innerHTML = '';

    if (perfisCache.length === 0) {
        listaUsuariosContainer.innerHTML = '<div class="chat-list-empty">Nenhum perfil publicado ainda. Seja o primeiro da rede.</div>';
        return;
    }

    perfisCache.forEach((usuario) => {
        const cor = corDoAvatar(usuario.nome);
        const rotulo = ROTULOS_BOTAO[usuario.statusConexao] || ROTULOS_BOTAO.nenhuma;

        const card = document.createElement('div');
        card.className = 'profile-card';
        card.innerHTML = `
            <div>
                <div class="card-header">
                    <div class="avatar" style="background:${cor.bg}; color:${cor.fg};">${esc(gerarIniciais(usuario.nome))}</div>
                    <div class="user-info">
                        <h3>${esc(usuario.nome)}</h3>
                        <span>Membro verificado</span>
                    </div>
                </div>
                <div class="skills-container">
                    <div class="skill-row">
                        <span class="skill-label">Oferece</span>
                        <span class="skill-value ${usuario.ensina ? 'teach' : 'teach-empty'}">${esc(usuario.ensina) || 'Ainda não oferece nada'}</span>
                    </div>
                    <div class="skill-row">
                        <span class="skill-label">Busca</span>
                        <span class="skill-value learn">${esc(usuario.aprende)}</span>
                    </div>
                </div>
            </div>
            <button class="btn-connect ${rotulo.classe}" type="button"
                data-status="${usuario.statusConexao}"
                data-user-id="${usuario.user_id}"
                data-conexao-id="${usuario.conexaoId || ''}"
                data-conversation-id="${usuario.conversationId || ''}"
                ${rotulo.desativado ? 'disabled' : ''}>${rotulo.texto}</button>
        `;
        listaUsuariosContainer.appendChild(card);
    });
}

listaUsuariosContainer.addEventListener('click', async (event) => {
    const botao = event.target.closest('.btn-connect');
    if (!botao || botao.disabled) return;

    const status = botao.dataset.status;
    if (status === 'nenhuma') {
        await solicitarConexao(Number(botao.dataset.userId));
    } else if (status === 'pendente_recebida') {
        await aceitarConexaoNoExplorar(botao.dataset.conexaoId);
    } else if (status === 'aceita') {
        await trocarView('privada');
        abrirChat(botao.dataset.conversationId);
    }
});

async function solicitarConexao(destinatarioId) {
    try {
        await api('/api/connections', { metodo: 'POST', corpo: { destinatario_id: destinatarioId } });
        mostrarToast('Solicitação enviada', 'A pessoa vai receber um aviso para aceitar.', 'success');
        await carregarPerfis();
    } catch (e) {
        mostrarToast('Não foi possível conectar', e.message, 'error');
    }
}

async function aceitarConexaoNoExplorar(conexaoId) {
    try {
        await api(`/api/connections/${conexaoId}/aceitar`, { metodo: 'POST' });
        mostrarToast('Conexão aceita', 'A conversa já está disponível na Área privada.', 'success');
        await carregarPerfis();
        await carregarConversas();
    } catch (e) {
        mostrarToast('Não foi possível aceitar', e.message, 'error');
    }
}

cadastroForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const botao = cadastroForm.querySelector('.btn-submit');

    const ensina = document.getElementById('ensina').value;
    const aprende = document.getElementById('aprende').value;

    definirCarregando(botao, true);
    try {
        await api('/api/profiles', { metodo: 'POST', corpo: { ensina, aprende } });
        cadastroForm.reset();
        mostrarToast('Perfil publicado', 'Sua disponibilidade já está visível na rede.', 'success');
        await carregarPerfis();
    } catch (e) {
        mostrarToast('Não foi possível publicar', e.message, 'error');
    } finally {
        definirCarregando(botao, false, 'Publicar disponibilidade');
    }
});

/* =========================================================
   Área privada: conversas
   ========================================================= */
async function carregarConversas() {
    try {
        const { conversas, pendentesRecebidas } = await api('/api/conversations');
        conversasCache = conversas;
        atualizarBadge();
        if (socket && socket.connected) {
            socket.emit('conversas:entrar', conversas.map((c) => c.conversationId));
        }
        renderizarChats(pendentesRecebidas);
        return conversas;
    } catch (e) {
        mostrarToast('Erro ao carregar conversas', e.message, 'error');
        return [];
    }
}

function criarItemChat({ id, titulo, preview, naoLidas, pendente, onAceitar }) {
    const cor = corDoAvatar(titulo);
    const item = document.createElement('div');
    item.className = 'chat-item' + (id === chatAtivoId ? ' active' : '') + (pendente ? ' pending' : '');
    if (!pendente) item.addEventListener('click', () => abrirChat(id));

    const avatar = document.createElement('div');
    avatar.className = 'avatar';
    avatar.style.background = cor.bg;
    avatar.style.color = cor.fg;
    avatar.textContent = gerarIniciais(titulo);

    const info = document.createElement('div');
    info.className = 'chat-item-info';
    const nomeEl = document.createElement('strong');
    nomeEl.textContent = titulo;
    const previewEl = document.createElement('span');
    previewEl.textContent = preview;
    info.append(nomeEl, previewEl);

    item.append(avatar, info);

    if (pendente && onAceitar) {
        const aceitar = document.createElement('button');
        aceitar.className = 'chat-item-accept';
        aceitar.type = 'button';
        aceitar.textContent = 'Aceitar';
        aceitar.addEventListener('click', onAceitar);
        item.appendChild(aceitar);
    } else if (naoLidas > 0) {
        const b = document.createElement('span');
        b.className = 'badge';
        b.style.marginLeft = 'auto';
        b.textContent = naoLidas;
        item.appendChild(b);
    }
    return item;
}

function previewDaConversa(conversa) {
    if (!conversa.ultimaMensagem) return 'Sem mensagens ainda';
    const prefixo = conversa.ultimaMensagem.autor_nome === contaAtual.nome ? 'Você: ' : '';
    return prefixo + conversa.ultimaMensagem.texto;
}

function adicionarSecao(lista, rotulo, itens) {
    if (itens.length === 0) return;
    const titulo = document.createElement('div');
    titulo.className = 'chat-section-label';
    titulo.textContent = rotulo;
    lista.appendChild(titulo);
    itens.forEach((i) => lista.appendChild(i));
}

function renderizarChats(pendentesRecebidas) {
    const lista = document.getElementById('listaChats');
    lista.innerHTML = '';

    if (conversasCache.length === 0 && (!pendentesRecebidas || pendentesRecebidas.length === 0)) {
        lista.innerHTML = '<div class="chat-list-empty">Nenhuma conversa ainda. Proponha uma conexão na aba Explorar; quando o membro aceitar, a conversa aparece aqui.</div>';
        return;
    }

    const grupos = conversasCache.filter((c) => c.tipo === 'grupo').map((c) => criarItemChat({
        id: c.conversationId, titulo: c.titulo, preview: previewDaConversa(c), naoLidas: c.naoLidas
    }));
    const diretas = conversasCache.filter((c) => c.tipo === 'dm').map((c) => criarItemChat({
        id: c.conversationId, titulo: c.titulo, preview: previewDaConversa(c), naoLidas: c.naoLidas
    }));
    const pendentes = (pendentesRecebidas || []).map((p) => criarItemChat({
        id: `pendente:${p.conexao_id}`,
        titulo: p.nome,
        preview: 'Quer se conectar com você',
        pendente: true,
        onAceitar: async () => {
            try {
                await api(`/api/connections/${p.conexao_id}/aceitar`, { metodo: 'POST' });
                mostrarToast('Conexão aceita', `Você e ${p.nome} já podem conversar.`, 'success');
                await carregarConversas();
            } catch (e) {
                mostrarToast('Não foi possível aceitar', e.message, 'error');
            }
        }
    }));

    adicionarSecao(lista, 'Grupos', grupos);
    adicionarSecao(lista, 'Conexões', diretas);
    adicionarSecao(lista, 'Solicitações recebidas', pendentes);
}

async function abrirChat(id) {
    try {
        const { mensagens, info } = await api(`/api/conversations/${encodeURIComponent(id)}/mensagens`);
        chatAtivoId = id;
        if (socket && socket.connected) socket.emit('conversa:entrar', id);

        renderizarCabecalhoChat(info);
        const container = document.getElementById('chatMensagens');
        container.innerHTML = '';
        mensagens.forEach(renderizarMensagemNaTela);
        container.scrollTop = container.scrollHeight;

        await marcarComoLido(id, { silencioso: true });
        document.getElementById('chatTexto').focus();
    } catch (e) {
        mostrarToast('Não foi possível abrir a conversa', e.message, 'error');
    }
}

function renderizarCabecalhoChat(info) {
    const vazio = document.getElementById('chatVazio');
    const ativo = document.getElementById('chatAtivo');
    vazio.classList.toggle('hidden', !!info);
    ativo.classList.toggle('hidden', !info);
    if (!info) return;

    const titulo = info.tipo === 'dm' ? info.outroUsuario.nome : info.grupo.nome;
    const subtitulo = info.tipo === 'dm' ? 'Conversa individual' : 'Grupo';

    document.getElementById('chatTitulo').textContent = titulo;
    document.getElementById('chatSubtitulo').textContent = subtitulo;
    document.getElementById('btnAddMembros').classList.toggle('hidden', info.tipo !== 'grupo');
}

function renderizarMensagemNaTela(m) {
    const container = document.getElementById('chatMensagens');
    const el = document.createElement('div');

    if (m.tipo === 'sistema') {
        el.className = 'msg msg-system';
        el.textContent = m.texto;
    } else {
        const minha = m.autor_id === contaAtual.id;
        el.className = 'msg' + (minha ? ' mine' : '');
        if (!minha) {
            const autor = document.createElement('span');
            autor.className = 'msg-author';
            autor.textContent = m.autor_nome;
            el.appendChild(autor);
        }
        el.appendChild(document.createTextNode(m.texto));
    }
    container.appendChild(el);
    container.scrollTop = container.scrollHeight;
}

async function marcarComoLido(id, { silencioso } = {}) {
    try {
        await api(`/api/conversations/${encodeURIComponent(id)}/lida`, { metodo: 'POST' });
        if (!silencioso) await carregarConversas();
        else {
            const conversa = conversasCache.find((c) => c.conversationId === id);
            if (conversa) conversa.naoLidas = 0;
            atualizarBadge();
        }
    } catch (e) { /* leitura é best-effort */ }
}

document.getElementById('chatForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const campo = document.getElementById('chatTexto');
    const texto = campo.value.trim();
    if (!texto || !chatAtivoId) return;

    campo.value = '';
    try {
        const { mensagem } = await api(`/api/conversations/${encodeURIComponent(chatAtivoId)}/mensagens`, {
            metodo: 'POST',
            corpo: { texto }
        });
        renderizarMensagemNaTela(mensagem);
        carregarConversas();
    } catch (e) {
        mostrarToast('Mensagem não enviada', e.message, 'error');
        campo.value = texto;
    }
});

/* =========================================================
   Grupos
   ========================================================= */
function abrirModal(id) { document.getElementById(id).classList.remove('hidden'); }
function fecharModal(id) {
    document.getElementById(id).classList.add('hidden');
    if (id === 'modalVideo') document.getElementById('videoFrame').innerHTML = '';
}

document.querySelectorAll('[data-close-modal]').forEach((btn) => {
    btn.addEventListener('click', () => fecharModal(btn.closest('.modal-overlay').id));
});

document.querySelectorAll('.modal-overlay').forEach((overlay) => {
    overlay.addEventListener('mousedown', (event) => {
        if (event.target === overlay) fecharModal(overlay.id);
    });
});

document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    document.querySelectorAll('.modal-overlay:not(.hidden)').forEach((m) => fecharModal(m.id));
});

async function abrirModalGrupo(modo) {
    modalGrupoModo = modo;
    let candidatos;
    try {
        const { conexoes } = await api('/api/connections/aceitas');
        candidatos = conexoes;
    } catch (e) {
        mostrarToast('Erro ao carregar conexões', e.message, 'error');
        return;
    }

    if (modo === 'adicionar') {
        const jaNoGrupo = new Set(
            (document.getElementById('chatTitulo').dataset.membros || '').split(',').filter(Boolean)
        );
        candidatos = candidatos.filter((c) => !jaNoGrupo.has(String(c.id)));
    }

    document.getElementById('modalGrupoTitulo').textContent = modo === 'criar' ? 'Novo grupo' : 'Adicionar membros';
    document.getElementById('grupoNomeGroup').classList.toggle('hidden', modo !== 'criar');
    document.getElementById('grupoSalvarBtn').textContent = modo === 'criar' ? 'Criar grupo' : 'Adicionar';
    document.getElementById('grupoNome').value = '';

    const lista = document.getElementById('grupoMembros');
    lista.innerHTML = '';
    if (candidatos.length === 0) {
        lista.innerHTML = '<div class="chat-list-empty">Nenhuma conexão aceita disponível. Conecte-se com membros na aba Explorar.</div>';
    }
    candidatos.forEach((c) => {
        const rotulo = document.createElement('label');
        rotulo.className = 'check-item';
        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.name = 'membro';
        cb.value = c.id;
        rotulo.append(cb, document.createTextNode(c.nome));
        lista.appendChild(rotulo);
    });

    abrirModal('modalGrupo');
}

document.getElementById('btnNovoGrupo').addEventListener('click', () => abrirModalGrupo('criar'));
document.getElementById('btnAddMembros').addEventListener('click', () => abrirModalGrupo('adicionar'));

document.getElementById('grupoForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const selecionados = Array.from(document.querySelectorAll('#grupoMembros input[name="membro"]:checked')).map((cb) => Number(cb.value));

    if (selecionados.length === 0) {
        mostrarToast('Selecione membros', 'Escolha ao menos uma conexão aceita.', 'error');
        return;
    }

    try {
        if (modalGrupoModo === 'criar') {
            const nome = document.getElementById('grupoNome').value.trim();
            if (!nome) {
                mostrarToast('Nome do grupo', 'Dê um nome ao grupo.', 'error');
                return;
            }
            const { conversationId } = await api('/api/groups', { metodo: 'POST', corpo: { nome, membros: selecionados } });
            fecharModal('modalGrupo');
            await carregarConversas();
            socket.emit('conversa:entrar', conversationId);
            abrirChat(conversationId);
            mostrarToast('Grupo criado', `"${nome}" já está na sua lista de conversas.`, 'success');
        } else {
            const groupId = chatAtivoId.slice(4);
            await api(`/api/groups/${groupId}/membros`, { metodo: 'POST', corpo: { membros: selecionados } });
            fecharModal('modalGrupo');
            await abrirChat(chatAtivoId);
            await carregarConversas();
        }
    } catch (e) {
        mostrarToast('Não foi possível salvar', e.message, 'error');
    }
});

/* =========================================================
   Videochamada (sala Jitsi Meet, sem servidor próprio)
   ========================================================= */
document.getElementById('btnVideochamada').addEventListener('click', async () => {
    if (!chatAtivoId) return;
    try {
        const { link } = await api(`/api/conversations/${encodeURIComponent(chatAtivoId)}/sala-video`);
        document.getElementById('videoTitulo').textContent = `Videochamada · ${document.getElementById('chatTitulo').textContent}`;

        const frame = document.getElementById('videoFrame');
        frame.innerHTML = '';
        const iframe = document.createElement('iframe');
        iframe.allow = 'camera; microphone; fullscreen; display-capture; autoplay';
        iframe.src = `${link}#userInfo.displayName=${encodeURIComponent(JSON.stringify(contaAtual.nome))}`;
        frame.appendChild(iframe);
        frame.dataset.link = link;

        abrirModal('modalVideo');
    } catch (e) {
        mostrarToast('Não foi possível abrir a sala', e.message, 'error');
    }
});

document.getElementById('btnEncerrarVideo').addEventListener('click', () => fecharModal('modalVideo'));

document.getElementById('btnAbrirAba').addEventListener('click', () => {
    const link = document.getElementById('videoFrame').dataset.link;
    if (link) window.open(link, '_blank', 'noopener');
});

document.getElementById('btnCopiarConvite').addEventListener('click', async () => {
    const link = document.getElementById('videoFrame').dataset.link;
    if (!link) return;
    try {
        await navigator.clipboard.writeText(link);
        mostrarToast('Link copiado', 'Envie o convite para quem deve entrar na chamada.', 'success');
    } catch (e) {
        mostrarToast('Não foi possível copiar', link, 'error');
    }
});

/* =========================================================
   Excluir conta
   ========================================================= */
const excluirForm = document.getElementById('excluirForm');
const excluirError = document.getElementById('excluirError');

document.getElementById('btnExcluirConta').addEventListener('click', () => {
    excluirForm.reset();
    excluirError.classList.remove('visible');
    abrirModal('modalExcluir');
    document.getElementById('excluirSenha').focus();
});

excluirForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const senha = document.getElementById('excluirSenha').value;

    try {
        await api('/api/account', { metodo: 'DELETE', corpo: { senha } });
        fecharModal('modalExcluir');
        sair();
        mostrarToast('Conta excluída', 'Sua conta e seus dados foram removidos.', 'success');
    } catch (e) {
        excluirError.textContent = e.message;
        excluirError.classList.add('visible');
    }
});
