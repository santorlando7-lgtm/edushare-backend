require('dotenv').config();

const path = require('path');
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const configurarSocket = require('./src/socket');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/auth', require('./src/routes/auth'));
app.use('/api/profiles', require('./src/routes/profiles'));
app.use('/api/connections', require('./src/routes/connections'));
app.use('/api/groups', require('./src/routes/groups'));
app.use('/api/conversations', require('./src/routes/conversations'));
app.use('/api/account', require('./src/routes/account'));

app.get('/api/saude', (req, res) => res.json({ ok: true }));

const servidorHttp = http.createServer(app);
const io = new Server(servidorHttp, { cors: { origin: '*' } });
app.set('io', io);
configurarSocket(io);

const PORTA = process.env.PORT || 3000;
servidorHttp.listen(PORTA, () => {
    console.log(`EduShare rodando em http://localhost:${PORTA}`);
});
